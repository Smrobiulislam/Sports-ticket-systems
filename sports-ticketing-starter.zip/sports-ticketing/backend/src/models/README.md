Production data model placeholders:
- User
- Event
- TicketTier
- Order
- Ticket
- Attendee/CheckIn

Keep persistence behind services/repositories so seat selection and notifications can be added later.
