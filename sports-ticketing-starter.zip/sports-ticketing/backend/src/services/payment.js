// Payment provider abstraction.
// Replace this demo function with Stripe/Adyen/etc. when API keys are supplied.
export async function createCheckoutSession({ amount, currency='usd', orderId }) {
  return { id:`demo_checkout_${orderId}`, amount, currency, status:'demo' }
}
