// Email/SMS adapter placeholder.
// Add provider implementation later without changing order/ticket controllers.
export async function sendTicketNotification({ email, ticket }) {
  return { delivered: false, mode: 'demo', email, ticketId: ticket.id }
}
