import { v4 as uuid } from 'uuid'

export function createTicket({ event, tier, email }) {
  return {
    id: `tkt_${uuid().slice(0,8)}`,
    ticketCode: `SP-${uuid().slice(0,8).toUpperCase()}`,
    validationToken: uuid(),
    eventName: event.name,
    venue: event.venue,
    date: event.date,
    tierName: tier.name,
    email
  }
}
