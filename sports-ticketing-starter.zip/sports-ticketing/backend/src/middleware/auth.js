// Production: replace with JWT/session authentication and organizer roles.
export function requireOrganizer(req, res, next) {
  next()
}
